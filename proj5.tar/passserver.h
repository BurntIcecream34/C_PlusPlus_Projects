#ifndef DL_PASSSERVER_H
#define DL_PASSSERVER_H
#include <iostream>
#include "hashtable.h"

namespace cop4530 {
    class PassServer : private HashTable<string, string> {
	public:
	    PassServer(size_t size = 101);
	    ~PassServer();
	    bool load(const char *filename);
	    bool addUser(std::pair<string,  string> & kv);
	    bool addUser(std::pair<string, string> && kv);
	    bool removeUser(const string & k);
	    bool changePassword(const pair<string, string> &p, const string & newpassword);
	    bool find(const string & user) const;
	    void dump();
	    size_t size() const;
	    bool write_to_file(const char *filename) const;
	private:
	    HashTable<string, string> table;
	    string encrypt(const string & str);
    };
}

#endif

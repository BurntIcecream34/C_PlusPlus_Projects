#include "passserver.h"
#include <crypt.h>
#include <cstring>

using namespace std;
using namespace cop4530;

// public
PassServer::PassServer(size_t size) : table(size) {}

PassServer::~PassServer() {
    table.clear();
}

bool PassServer::load(const char *filename) {
    return table.load(filename);
}

bool PassServer::addUser(std::pair<string,  string> & kv) {
    string password = encrypt(kv.second);
    return table.insert(make_pair(kv.first, password));
}

bool PassServer::addUser(std::pair<string, string> && kv) {
    auto tmp = std::move(kv);
    return addUser(tmp);
}

bool PassServer::removeUser(const string & k) {
    return table.remove(k);
}

bool PassServer::changePassword(const pair<string, string> &p, const string & newpassword) {
    if (!table.contains(p.first)) {
	return false;
    }

    string oldP = encrypt(p.second);
    string newP = encrypt(newpassword);

    if (!table.match(make_pair(p.first, oldP))) {
	return false;
    }

    if (oldP == newP) {
	return false;
    }

    return table.insert(make_pair(p.first, newP));
}

bool PassServer::find(const string & user) const {
    return table.contains(user);
}

void PassServer::dump() {
    table.dump();
}

size_t PassServer::size() const {
    return table.size();
}

bool PassServer::write_to_file(const char *filename) const {
    return table.write_to_file(filename);
}

// private
// HashTable<string, string> table;
string PassServer::encrypt(const string & str) {
    char salt[] = "$1$########";
    string cPass = "";

    char * password = new char [100];
    strcpy ( password, crypt(str.c_str(), salt));
    for (int i = 12; i < strlen(password); i++) {
	cPass += password[i];
    }
    delete password;
    return cPass;
}

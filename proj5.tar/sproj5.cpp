#include <iostream>
#include "hashtable.h"
#include "passserver.h"
#include "termios.h"
#include <limits>
using namespace std;
using namespace cop4530;

void Menu();
void showPass();
void hidePass();

int main() {
    int cap;
    cout << "Enter preferred hash table capacity (integer): ";
    while (!(cin >> cap)) {
	cout << "Enter preferred hash table capacity (integer): ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    PassServer ht(cap);

    char choice;    
    Menu();
    cin >> choice;
    cout << "choice: " << choice << '\n';
    while (choice != 'x') {
	switch (choice) {
	    case 'l':
		{
		char * f = new char[100];
		cout << "Enter password file name to load from: ";
		cin >> f;
		ht.load(f);	
		delete [] f;
		break;
		}
	    case 'a':
		{
		string user;
		string pass;
		cout << "Enter username: ";
		cin >> user;
		hidePass();
		cout << "Enter password: ";
		cin >> pass;
		showPass();
		if (ht.addUser(make_pair(user, pass))) {
		    cout << '\n' << "User " << user << " added.\n";
		}
		else {
		    cout << "\nUser not added.\n";
		}		
		break;
		}
	    case 'r':
		{
		string user;
		cout << "Enter username: ";
		cin >> user;
		if (ht.removeUser(user)) {
		    cout << "User " << user << " deleted.\n";
		}
		else {
		    cout << "\n*****Error: User not found.  Could not delete user\n";
		}				
		break;
		}
	    case 'c':
		{
		string user;
		string pass;
		string newPass;
		cout << "Enter username: ";
		cin >> user;
		hidePass();
		cout << "Enter password: ";
		cin >> pass;
		cout << "\nEnter new password: ";
		cin >> newPass;
		showPass();
		if (ht.changePassword(make_pair(user, pass), newPass)) {
		    cout << "\nPassword changed for user " << user << '\n';
		}
		else {
		    cout << "\n*****Error: Could not change user password\n";
		}	
		break;
		}
	    case 'f':
		{
		string user;
		cout << "Enter username: ";
		cin >> user;
		if (ht.find(user)) {
		    cout << "\nUser '" << user << "' found.\n";		    
		}
		else {
		    cout << "\nUser '" << user << "' not found.\n";
		}		
		break;
		}
	    case 'd':
		{
		ht.dump();
		cout << '\n';		
		break;
		}
	    case 's':
		{
		cout << "Size of hashtable: " << ht.size() << '\n';			
		break;
		}
	    case 'w':
		{
		char * filename = new char[100];
		cout << "Enter password file name to write to: ";
		cin >> filename;
		ht.write_to_file(filename);
		break;
		}
	}
	Menu();
	cin >> choice;
	cout << "choice: " << choice << '\n';
    }

    return 0;
}

void Menu()
{
  cout << "\n\n";
  cout << "l - Load From File" << endl;
  cout << "a - Add User" << endl;
  cout << "r - Remove User" << endl;
  cout << "c - Change User Password" << endl;
  cout << "f - Find User" << endl;
  cout << "d - Dump HashTable" << endl;
  cout << "s - HashTable Size" << endl;
  cout << "w - Write to Password File" << endl;
  cout << "x - Exit program" << endl;
  cout << "\nEnter choice : ";
}

void showPass() {
    termios oldSet;
    tcgetattr(STDIN_FILENO, & oldSet); // Get the current terminal settings
    oldSet.c_lflag |= ECHO;           // Turn on echo
    tcsetattr(STDIN_FILENO, TCSANOW, & oldSet); // Apply the new settings
}

void hidePass() {
    termios oldSet, newSet;
    tcgetattr(STDIN_FILENO, & oldSet); // Get the current terminal settings
    newSet = oldSet; 
    newSet.c_lflag &= ~ECHO;           // Turn off echo
    tcsetattr(STDIN_FILENO, TCSANOW, & newSet); // Apply the new settings
}

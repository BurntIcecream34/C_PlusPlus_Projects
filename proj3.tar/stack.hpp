#include <iostream>
#include <vector>
#include "stack.h"

using namespace std;
using namespace cop4530;

template <typename T, class Container>
Stack<T, Container>::Stack() : c() {}
template <typename T, class Container>
Stack<T, Container>::~Stack() {
    if (!empty()) {
	clear();
    }
}
template <typename T, class Container>
Stack<T, Container>::Stack(const Stack<T, Container> & s) : c{s.c} {}  
template <typename T, class Container> 
Stack<T, Container>::Stack(Stack<T, Container> && s) : c{std::move(s.c)} {
    s.clear();
}
template <typename T, class Container>
Stack<T, Container> & Stack<T, Container>::operator=(const Stack <T, Container> & s) {
    if (this != &s) {
        (*this).c = s.c;
    }
    return *this;
}
template <typename T, class Container>
Stack<T, Container> & Stack<T, Container>::operator=(Stack<T, Container> && s) {
    if (this != &s) {
        (*this).c = std::move(s.c);
    }
    return *this;
}
template <typename T, class Container>
bool Stack<T, Container>::empty() const {
    return c.size() == 0;
}  
template <typename T, class Container>
void Stack<T, Container>::clear() {
    while (!empty()) {
	c.pop_back();
    }
}
// Back of vector is top of stack
template <typename T, class Container>
void Stack<T, Container>::push(const T & x) {
    c.push_back(x);
}
template <typename T, class Container>
void Stack<T, Container>::push(T && x) {
    c.push_back(std::move(x));
}
template <typename T, class Container>
void Stack<T, Container>::pop() {
    c.pop_back();
}  
template <typename T, class Container>
T & Stack<T, Container>::top() {
    return c.back();
}
template <typename T, class Container>
const T & Stack<T, Container>::top() const {
    return c.back();
}
template <typename T, class Container>
int Stack<T, Container>::size() const {
    return c.size();
}
template <typename T, class Container>
void Stack<T, Container>::print(std::ostream & os, char ofc) const {
    for (int i = 0; i < c.size(); i++) {
	os << c[i] << ofc;
    }
}

template <typename T, class Container>
Container Stack<T, Container>::getVector() const {
    return (*this).c;
}

// protected data member variables
// Container c;

template <typename T, class Container>	
std::ostream& operator<< (std::ostream& os, const Stack<T, Container>& a) {
    a.print(os, ' ');
    return os;
}
template <typename T, class Container>	
bool operator==(const Stack<T, Container>& a, const Stack <T, Container>& b) {
    if (a.size() != b.size()) {
	return false;
    }
    for (int i = 0; i < a.size(); i++) {
	if ((a.getVector())[i] != (b.getVector())[i]) {
	    return false;
	}
    }
    return true;
}
template <typename T, class Container>	
bool operator!= (const Stack<T, Container>& a, const Stack <T, Container>& b) {
    return !(a == b);
}
template <typename T, class Container>	
bool operator<=(const Stack<T, Container>& a, const Stack <T, Container>& b) {
    Stack<T, Container> aCopy = a;
    Stack<T, Container> bCopy = b;

    while (!aCopy.empty() && !bCopy.empty()) {
	// If the top element of stack a is greater than in b then its done
	if (aCopy.top() > bCopy.top()) {
	    return false;
	}
	// Remove the two top elements
	aCopy.pop();
	bCopy.pop();
    }
    return true;
}

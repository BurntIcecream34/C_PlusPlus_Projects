#include <iostream>
#include <string>
#include <cctype>
#include <cstdlib>
#include "stack.h"

using namespace std;
using namespace cop4530;

float evaluate(const string & postfix);
string convert(const string & infix);

int main() {
    string choice;
    string postfix;
    float num;
    cout << "Enter infix expression (\"exit\" to quit): ";
    while (true) {
	getline(cin, choice);
	if (choice == "exit") {
	    break;
	}
	postfix = convert(choice);
	cout << "Converted expression: ";
	cout << postfix << "\n";
	num = evaluate(postfix);
	cout << "Evaluated postfix: " << num << "\n";
    	cout << "Enter infix expression (\"exit\" to quit): ";
    }
    return 0;
}

int precedence(char op) {
    if (op == '+' || op == '-') { 
	return 1;
    }
    if (op == '*' || op == '/') {
	return 2;
    }
    return 0; 
}

string convert(const string& infix) {
    Stack<char> operators;
    string postfix;

    for (size_t i = 0; i < infix.size(); i++) {
        if (isspace(infix[i])) {
            continue;
        }

        if (isalnum(infix[i])) {
            postfix += infix[i];
        }
        else if (infix[i] == '(') {
            operators.push(infix[i]);
        }
        else if (infix[i] == ')') {
            while (!operators.empty() && operators.top() != '(') {
                postfix += operators.top();
                operators.pop();
            }
            if (operators.empty()) {
                cout << "Error: Mismatched parentheses\n";
                return "";
            }
            operators.pop();
        }
        else { 
            while (!operators.empty() && precedence(operators.top()) >= precedence(infix[i])) {
                postfix += operators.top();
                operators.pop();
            }
            operators.push(infix[i]);
        }
    }

    // Pop all of the remaining operators
    while (!operators.empty()) {
        if (operators.top() == '(') {
            cout << "Error: Mismatched parentheses\n";
            return "";
        }
        postfix += operators.top();
        operators.pop();
    }

    return postfix;
}

float evaluate(const string & postfix) {
    Stack<float> operands;

    for (int i = 0; i < postfix.size(); i++) {
	char temp = postfix[i];
	
	if (isspace(temp)) {
	    continue;
	}

	if ((temp == '-' && (i == 0 || postfix[i - 1] == ' ')) || isdigit(temp)) {
	    string temp2;
	    if (temp == '-') {
		temp2 += temp;
		i++;
	    }
	 
	    while (i < postfix.size() && (isdigit(postfix[i]) || postfix[i] == '.')) {
		temp2 += postfix[i++];
	    }
	    operands.push(stof(temp2));
	    i--;
	}
	else if (isalpha(temp)) {
            cout << postfix << "\n";
            return -1;
	}
	else {
	    if (operands.size() < 2) {
                cout << "Error: Not enough operands for operator '" << temp << "'\n";
                return -1;
            }
	
	    float operandTwo = operands.top();
	    operands.pop();
	    float operandOne = operands.top();
	    operands.pop();

	    if (temp == '+') {
                operands.push(operandOne + operandTwo);
            } 
	    else if (temp == '-') {
                operands.push(operandOne - operandTwo);
            } 
	    else if (temp == '*') {
                operands.push(operandOne * operandTwo);
            } 
	    else if (temp == '/') {
                if (operandTwo == 0) {
                    cout << "Error: Dividing by a zero\n";
                    return -1;
                }
                operands.push(operandOne / operandTwo);
            } 
	    else {
                cout << "Error: operator unknown '" << temp << "'\n";
                return -1;
            }
	}
    }

    if (operands.size() == 1) {
	return operands.top();
    }
    else if (operands.size() > 1) {
	cout << "Error: Too much left in stack\n";
	return -1;
    }

    return 0;
}

#ifndef DL_STACK_H
#define DL_STACK_H

#include <iostream>
#include <vector>

using namespace std;

namespace cop4530 {
    template <typename T, class Container = vector<T>>
	class Stack {
	    public:
		Stack();
		~Stack ();
		Stack (const Stack<T, Container> & s);   
		Stack(Stack<T, Container> && s);
		Stack<T, Container> & operator=(const Stack <T, Container> & s);
		Stack<T, Container> & operator=(Stack<T, Container> && s);
		bool empty() const;
		void clear();
		void push(const T & x);
		void push(T && x);
		void pop();  
		T & top();
		const T & top() const; 
		int size() const;
		void print(std::ostream& os, char ofc = ' ') const;
		Container getVector() const;

	    protected:
		Container c;
	};
	
        template <typename T, class Container>
		std::ostream& operator<< (std::ostream& os, const Stack<T>& a);    
	template <typename T, class Container>
		bool operator== (const Stack<T, Container>& a, const Stack <T, Container>& b);  
	template <typename T, class Container>
		bool operator!= (const Stack<T, Container>& a, const Stack <T, Container>& b);
	template <typename T, class Container>
		bool operator<=(const Stack<T, Container>& a, const Stack<T, Container>& b);

    #include "stack.hpp"
}
// the end of the namespace

#endif

